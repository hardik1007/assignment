export class Product {
    productName: string;
    productPrice: number;

    constructor(name: string, price: number) {
        this.productName = name;
        this.productPrice = price;
    }
}