import { Injectable } from "@angular/core";
import { Product } from "../domain/product";

@Injectable()
export class CrudService {

    products: Array<Product> = new Array<Product>();

    constructor() {
        this.products = [new Product('Product One', 22.50),
        new Product('Product Two', 15.00)]
    }

    createProduct(product: Product) {
        this.products.push(product);
    }

    readProduct() {
        return this.products;
    }

    updateProduct(index: number, product: Product) {
        this.products[index] = product;
    }

    deleteProduct(index: number) {
        this.products.splice(index,1);
    }

}