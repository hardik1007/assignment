import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DataTableModule, ButtonModule } from 'primeng/primeng';

import { AppComponent } from './app.component';
import { CrudComponent } from './crud/crud.component';
import { CrudService } from './service/crud.service';
import { AddProductComponent } from './crud/add-product/add-product.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    CrudComponent,
    AddProductComponent
  ],
  imports: [
    BrowserModule,
    DataTableModule,
    ButtonModule,
    FormsModule
  ],
  providers: [CrudService],
  bootstrap: [AppComponent]
})
export class AppModule { }
