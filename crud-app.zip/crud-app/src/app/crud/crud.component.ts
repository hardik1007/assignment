import { Component, OnInit } from '@angular/core';
import { CrudService } from '../service/crud.service';
import { Product } from '../domain/product';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {

  productName: string;
  productPrice: number;
  addOrEdit: string;
  index: number;

  constructor(public crudService: CrudService) { }

  ngOnInit() {
  }

  OnEditButtonClick(index: number) {
    this.productName = this.crudService.products[index].productName;
    this.productPrice = this.crudService.products[index].productPrice;
    this.addOrEdit = 'Edit';
    this.index = index;
  }

  onDeleteButtonClick(index: number) {
    this.crudService.deleteProduct(index);
  }
  submit() {
    if (this.addOrEdit === 'Add') {
      const product = new Product(this.productName, this.productPrice);
      this.crudService.createProduct(product);
    }
    else {
      const product = new Product(this.productName, this.productPrice);
      this.crudService.updateProduct(this.index, product);
    }
  }
  resetValues() {
    this.addOrEdit = 'Add';
    this.productName = '';
    this.productPrice = 0
  }
}
